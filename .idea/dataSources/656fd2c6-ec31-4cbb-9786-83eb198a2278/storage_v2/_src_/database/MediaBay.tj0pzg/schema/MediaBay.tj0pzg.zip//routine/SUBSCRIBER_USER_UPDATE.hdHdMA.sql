CREATE FUNCTION "SUBSCRIBER_USER_UPDATE"()
  RETURNS TABLE(subscriber_user_id_updates integer, subscriber_email_address_updates integer, subscriber_date_modified_updates integer, subscriber_etl_date_updates integer, subscriber_is_matched_updates integer, subscriber_matched_user_id_updates integer, subscriber_is_monster_user_updates integer, subscriber_email_address_status_id_updates integer, subscriber_is_trillium_matched_updates integer, subscribre_add_first_name_updates integer, subscribre_add_last_name_updates integer, subscribre_add_phone_number_updates integer, subscribre_add_postal_code_updates integer, subscribre_add_date_modified_ipdates integer, subscribre_add_etl_date_updates integer, subscribre_add_state_id_updates integer, subscribre_add_city_updates integer)
LANGUAGE plpgsql
AS $$
DECLARE
		--"MediaBay"."S_(01)_SubscriberInfoDetails"
		subscriber_user_id_updates integer; subscriber_email_address_updates integer; subscriber_date_modified_updates integer; subscriber_etl_date_updates integer; subscriber_is_matched_updates integer; subscriber_matched_user_id_updates integer;
		subscriber_is_monster_user_updates integer; subscriber_email_address_status_id_updates integer; subscriber_is_trillium_matched_updates integer;
		--"MediaBay"."S_(02)_SubscriberAccountDetails"
		--subscriber_name_prefix_id_updated integer; subscriber_first_name_updated integer; subscriber_middle_name_updated integer; subscriber_lastname_updated integer; subscriber_name_sufix_updated integer; subscriber_country_id_updated integer; subscriber_state_id_updated integer; subscriber_cities_updated integer; 
		--subscriber_address1_updates integer; subscriber_address2_updates integer; subscriber_postal_code_updates integer; subscriber_us_zip5_updates integer; subscriber_location_id_updates integer; subscriber_confidential_updates integer; subscriber_disabled_updates integer; subscriber_channel_id_updates integer; 
		--subscriber_career_level_id_updates integer; subscriber_available_time_id_updates integer; subscriber_available_day_updates integer; subscriber_available_month_updates integer; subscriber_available_year_updates integer; subscriber_daytime_phone_updates integer; subscriber_evening_phone_updates integer; 
		--subscriber_mobile_phone_updates integer; subscriber_fax_updates integer; subscriber_pager_updates integer; subscriber_company_updates integer; subscriber_add_date_modified_updates integer; subscriber_date_deleted_updates integer; subscriber_add_etl_date_updates integer; subscriber_created_channel_id_updates integer; 
		--subscriber_add_email_address_updates integer;
		--"MediaBay"."S_(03)_SubscriberAdditionalInfo"
		subscribre_add_first_name_updates integer; subscribre_add_last_name_updates integer; subscribre_add_phone_number_updates integer; subscribre_add_postal_code_updates integer; subscribre_add_date_modified_ipdates integer; subscribre_add_etl_date_updates integer; 
		subscribre_add_state_id_updates integer; subscribre_add_city_updates integer;
		--"MediaBay"."S_(05)_SubscriberSubscriptionDetails"
		 --subscription_ip_address_updates integer; subscription_subscription_action_id_updates integer; subscription_object_type_id_updates integer; subscription_link_id_updates integer; subscription_channel_id_updates integer; subscription_etl_date_updates integer;
		BEGIN
			  -- "MediaBay"."S_(01)_SubscriberInfoDetails" -- user_id
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET user_id = ST.user_id
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND ST.user_id <> RT.user_id
					AND ST.user_id <> '0'
					AND ST.user_id IS NOT NULL;
					GET DIAGNOSTICS subscriber_user_id_updates = ROW_COUNT;
			-- "MediaBay"."S_(01)_SubscriberInfoDetails" -- email_address
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET email_address = (trim(both ' ' from ST.email_address))
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND (trim(both ' ' from ST.email_address)) <> RT.email_address
					AND ST.email_address IS NOT NULL;
					GET DIAGNOSTICS subscriber_email_address_updates = ROW_COUNT;
			-- "MediaBay"."S_(01)_SubscriberInfoDetails" -- date_modified
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET date_modified = ST.date_modified
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id= ST.subscriber_id
					AND ST.date_modified > RT.date_modified;
					GET DIAGNOSTICS subscriber_date_modified_updates = ROW_COUNT;
			-- "MediaBay"."S_(01)_SubscriberInfoDetails" -- etl_date
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET etl_date = ST.etl_date
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id= ST.subscriber_id
					AND ST.etl_date > RT.etl_date;
					GET DIAGNOSTICS subscriber_etl_date_updates = ROW_COUNT;
			-- "MediaBay"."S_(01)_SubscriberInfoDetails" -- is_matched
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET is_matched = ST.is_matched
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id= ST.subscriber_id
					AND ST.is_matched <> RT.is_matched;
					GET DIAGNOSTICS subscriber_is_matched_updates = ROW_COUNT;	
			-- "MediaBay"."S_(01)_SubscriberInfoDetails" -- matched_user_id
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET matched_user_id = ST.matched_user_id
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND ST.matched_user_id <> RT.matched_user_id
					AND ST.matched_user_id IS NOT NULL;
					GET DIAGNOSTICS subscriber_matched_user_id_updates = ROW_COUNT;
			-- "MediaBay"."S_(01)_SubscriberInfoDetails" -- is_monster_user
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET is_monster_user = ST.is_monster_user
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id= ST.subscriber_id
					AND ST.is_monster_user <> RT.is_monster_user;
					GET DIAGNOSTICS subscriber_is_monster_user_updates = ROW_COUNT;
			-- "MediaBay"."S_(01)_SubscriberInfoDetails" -- email_address_status_id
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET email_address_status_id = ST.email_address_status_id
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id= ST.subscriber_id
					AND ST.email_address_status_id <> RT.email_address_status_id
					AND ST.email_address_status_id <> 0
					AND ST.email_address_status_id IS NOT NULL;
					GET DIAGNOSTICS subscriber_email_address_status_id_updates = ROW_COUNT;
			-- "MediaBay"."S_(01)_SubscriberInfoDetails" -- email_address_status_id
			UPDATE "MediaBay"."S_(01)_SubscriberInfoDetails" RT 
					SET is_trillium_matched = ST.is_trillium_matched
			FROM "MediaBay"."S_STG_(01)_SubscriberInfoDetails" ST
			WHERE
					RT.subscriber_id= ST.subscriber_id
					AND ST.is_trillium_matched <> RT.is_trillium_matched
					AND ST.is_trillium_matched IS NOT NULL;
					GET DIAGNOSTICS subscriber_is_trillium_matched_updates = ROW_COUNT;
					
----------------- "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" -- first_name
			UPDATE "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT
					SET first_name = initcap(trim(both ' ' from ST.first_name))
			FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND RT.first_name <> initcap(trim(both ' ' from ST.first_name))
					AND initcap(trim(both ' ' from ST.first_name)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.first_name)) <> '0';
					GET DIAGNOSTICS subscribre_add_first_name_updates = ROW_COUNT;
			-- "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" -- last_name
			UPDATE "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT
					SET last_name = initcap(trim(both ' ' from ST.last_name))
			FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND RT.last_name <> initcap(trim(both ' ' from ST.last_name))
					AND initcap(trim(both ' ' from ST.last_name)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.last_name)) <> '0';
					GET DIAGNOSTICS subscribre_add_last_name_updates = ROW_COUNT;
			-- "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" -- phone_number
			UPDATE "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT
					SET phone_number = trim(both ' ' from ST.phone_number)
			FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND RT.phone_number <> trim(both ' ' from ST.phone_number)
					AND trim(both ' ' from ST.phone_number) IS NOT NULL
					AND trim(both ' ' from ST.phone_number) <> '0';
					GET DIAGNOSTICS subscribre_add_phone_number_updates = ROW_COUNT;
			-- "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" -- postal_code
			UPDATE "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT
					SET postal_code = trim(both ' ' from ST.postal_code)
			FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND RT.postal_code <> trim(both ' ' from ST.postal_code)
					AND trim(both ' ' from ST.postal_code) IS NOT NULL
					AND trim(both ' ' from ST.postal_code) <> '0';
					GET DIAGNOSTICS subscribre_add_postal_code_updates = ROW_COUNT;
			-- "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" -- date_modified
			UPDATE "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT
					SET date_modified = ST.date_modified
			FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND RT.date_modified <> ST.date_modified;
					GET DIAGNOSTICS subscribre_add_date_modified_ipdates = ROW_COUNT;
			-- "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" -- date_modified
			UPDATE "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT
					SET etl_date = ST.etl_date
			FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND RT.etl_date <> ST.etl_date;
					GET DIAGNOSTICS subscribre_add_etl_date_updates = ROW_COUNT;
			-- "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" -- state_id
			UPDATE "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT
					SET state_id = ST.state_id
			FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND RT.state_id <> ST.state_id
					AND ST.state_id <> '0';
					GET DIAGNOSTICS subscribre_add_state_id_updates = ROW_COUNT;
			-- "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" -- city 
			UPDATE "MediaBay"."S_(03)_SubscriberAdditionalInfo" RT
					SET city  = initcap(trim(both ' ' from ST.city))
			FROM "MediaBay"."S_STG_(03)_SubscriberAdditionalInfo" ST
			WHERE
					RT.subscriber_id = ST.subscriber_id
					AND RT.city  <> initcap(trim(both ' ' from ST.city))
					AND initcap(trim(both ' ' from ST.city)) IS NOT NULL
					AND initcap(trim(both ' ' from ST.city)) <> '0';
					GET DIAGNOSTICS subscribre_add_city_updates = ROW_COUNT;
					
--------------"MediaBay"."S_(05)_SubscriberSubscriptionDetails"
			-- "MediaBay"."S_(05)_SubscriberSubscriptionDetails" -- ip_address
			--UPDATE "MediaBay"."S_(05)_SubscriberSubscriptionDetails" RT
					--SET ip_address = ST.ip_address
			--FROM "MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails" ST
			--WHERE
					--RT.subscription_id = ST.subscription_id
					--AND RT.ip_address <> ST.ip_address
					--AND ST.ip_address <> '0'
					--AND ST.ip_address IS NOT NULL;
					--GET DIAGNOSTICS subscription_ip_address_updates = ROW_COUNT;
			-- "MediaBay"."S_(05)_SubscriberSubscriptionDetails" -- subscription_action_id
			--UPDATE "MediaBay"."S_(05)_SubscriberSubscriptionDetails" RT
					--SET subscription_action_id = ST.subscription_action_id
			--FROM "MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails" ST
			--WHERE
					--RT.subscription_id = ST.subscription_id
					--AND RT.subscription_action_id <> ST.subscription_action_id
					--AND ST.subscription_action_id <> '0'
					--AND ST.subscription_action_id IS NOT NULL;
					--GET DIAGNOSTICS subscription_subscription_action_id_updates = ROW_COUNT;
			-- "MediaBay"."S_(05)_SubscriberSubscriptionDetails" -- object_type_id
			--UPDATE "MediaBay"."S_(05)_SubscriberSubscriptionDetails" RT
					--SET object_type_id = ST.object_type_id
			--FROM "MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails" ST
			--WHERE
					--RT.subscription_id = ST.subscription_id
					--AND RT.object_type_id <> ST.object_type_id
					--AND ST.object_type_id <> '0'
					--AND ST.object_type_id IS NOT NULL;
					--GET DIAGNOSTICS subscription_object_type_id_updates = ROW_COUNT;
			-- "MediaBay"."S_(05)_SubscriberSubscriptionDetails" -- link_id
			--UPDATE "MediaBay"."S_(05)_SubscriberSubscriptionDetails" RT
					--SET link_id = ST.link_id
			--FROM "MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails" ST
			--WHERE
					--RT.subscription_id = ST.subscription_id
					--AND RT.link_id <> ST.link_id
					--AND ST.link_id <> '0'
					--AND ST.link_id IS NOT NULL;
					--GET DIAGNOSTICS subscription_link_id_updates = ROW_COUNT;
			-- "MediaBay"."S_(05)_SubscriberSubscriptionDetails" -- channel_id
			--UPDATE "MediaBay"."S_(05)_SubscriberSubscriptionDetails" RT
					--SET channel_id = ST.channel_id
			--FROM "MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails" ST
			--WHERE
					--RT.subscription_id = ST.subscription_id
					--AND RT.channel_id <> ST.channel_id
					--AND ST.channel_id <> '0'
					--AND ST.channel_id IS NOT NULL;
					--GET DIAGNOSTICS subscription_channel_id_updates = ROW_COUNT;
			-- "MediaBay"."S_(05)_SubscriberSubscriptionDetails" -- etl_date
			--UPDATE "MediaBay"."S_(05)_SubscriberSubscriptionDetails" RT
					--SET etl_date = ST.etl_date
			--FROM "MediaBay"."S_STG_(05)_SubscriberSubscriptionDetails" ST
			--WHERE
					--RT.subscription_id = ST.subscription_id
					--AND RT.etl_date <> ST.etl_date
					--AND ST.etl_date IS NOT NULL;
					--GET DIAGNOSTICS subscription_etl_date_updates = ROW_COUNT;					
																														
				RETURN QUERY SELECT subscriber_user_id_updates, subscriber_email_address_updates, subscriber_date_modified_updates, subscriber_etl_date_updates, subscriber_is_matched_updates, subscriber_matched_user_id_updates,
				subscriber_is_monster_user_updates, subscriber_email_address_status_id_updates, subscriber_is_trillium_matched_updates,
				--"MediaBay"."S_(02)_SubscriberAccountDetails"
				--subscriber_name_prefix_id_updated,  subscriber_first_name_updated, subscriber_middle_name_updated, subscriber_lastname_updated,  subscriber_name_sufix_updated, subscriber_country_id_updated, subscriber_state_id_updated, subscriber_cities_updated, 
				--subscriber_address1_updates, subscriber_address2_updates, subscriber_postal_code_updates, subscriber_us_zip5_updates, subscriber_location_id_updates, subscriber_confidential_updates, subscriber_disabled_updates, subscriber_channel_id_updates, 
				--subscriber_career_level_id_updates, subscriber_available_time_id_updates, subscriber_available_day_updates, subscriber_available_month_updates, subscriber_available_year_updates, subscriber_daytime_phone_updates, subscriber_evening_phone_updates, 
				--subscriber_mobile_phone_updates, subscriber_fax_updates, subscriber_pager_updates, subscriber_company_updates, subscriber_add_date_modified_updates, subscriber_date_deleted_updates, subscriber_add_etl_date_updates, subscriber_created_channel_id_updates, subscriber_add_email_address_updates;
				--"MediaBay"."S_(03)_SubscriberAdditionalInfo"
				subscribre_add_first_name_updates, subscribre_add_last_name_updates, subscribre_add_phone_number_updates, subscribre_add_postal_code_updates, subscribre_add_date_modified_ipdates, subscribre_add_etl_date_updates, subscribre_add_state_id_updates, subscribre_add_city_updates;
				--"MediaBay"."S_(05)_SubscriberSubscriptionDetails"
				--subscription_ip_address_updates, subscription_subscription_action_id_updates, subscription_object_type_id_updates, subscription_link_id_updates, subscription_channel_id_updates, subscription_etl_date_updates;
		END;

$$;

