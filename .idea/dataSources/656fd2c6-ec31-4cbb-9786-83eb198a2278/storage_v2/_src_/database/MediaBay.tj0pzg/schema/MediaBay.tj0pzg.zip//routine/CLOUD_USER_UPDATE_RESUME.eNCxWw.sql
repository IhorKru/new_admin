CREATE FUNCTION "CLOUD_USER_UPDATE_RESUME"()
  RETURNS TABLE(wants_permanent_updates integer, wants_contract_updates integer, wants_intern_updates integer, wants_temp_updates integer, wants_fulltime_updates integer, wants_parttime_updates integer, salary_updates integer, salary_type_id_updates integer, currency_id_updates integer, site_location_id_updates integer, commute_distance_updates integer, distance_id_updates integer, company_size_id_updates integer, category_id_updates integer, resume_title_updates integer, date_created_updates integer, date_modified_updates integer, will_relocate_updates integer, date_expires_updates integer, channel_id_updates integer, active_updates integer, date_deleted_updates integer, builder_id_updates integer, created_channel_id_updates integer, hourly_updates integer, wants_perdiem_updates integer, wants_overtime_updates integer, wants_weekends_updates integer, prefer_weekends_updates integer, date_sequential_updates integer, salary_from_updates integer, salary_from_normalised_updates integer, etl_date_updates integer, datasource_id_updates integer, source_id_updates integer, addinfo_has_pl_experience_updates integer, addinfo_largest_budget_answer_id_updates integer, addinfo_number_people_managed_answer_id_updates integer, addinfo_has_turn_arround_experience_updates integer, addinfo_turnarround_experience_updates integer, addinfo_has_ipo_experience_updates integer, addinfo_ipo_experience_updates integer, addinfo_has_startup_experience_updates integer, addinfo_startup_experience_updates integer, addinfo_has_merger_acquisition_experience_updates integer, addinfo_merger_acquisition_experience_updates integer, addinfo_has_entrepenuer_experience_updates integer, addinfo_entrepenuer_experience_updates integer, addinfo_user_language_id_written_in_updates integer, addinfo_resume_origin_id_updates integer, addinfo_resume_origin_desc_updates integer, addinfo_etl_date_updates integer)
LANGUAGE plpgsql
AS $$
DECLARE
	wants_permanent_updates integer; wants_contract_updates integer; wants_intern_updates integer; wants_temp_updates integer; wants_fulltime_updates integer; wants_parttime_updates integer; salary_updates integer; salary_type_id_updates integer;
	currency_id_updates integer; site_location_id_updates integer; commute_distance_updates integer; distance_id_updates integer; company_size_id_updates integer;  category_id_updates integer; resume_title_updates integer; date_created_updates integer;
	date_modified_updates integer; will_relocate_updates integer; date_expires_updates integer; channel_id_updates integer; active_updates integer; date_deleted_updates integer; builder_id_updates integer; created_channel_id_updates integer; hourly_updates integer;
	wants_perdiem_updates integer; wants_overtime_updates integer; wants_weekends_updates integer; prefer_weekends_updates integer; date_sequential_updates integer; salary_from_updates integer; salary_from_normalised_updates integer; etl_date_updates integer;
	datasource_id_updates integer; source_id_updates integer;
	--RESUME ADDITIONAL INFO
	addinfo_has_pl_experience_updates integer; addinfo_largest_budget_answer_id_updates integer; addinfo_number_people_managed_answer_id_updates integer; addinfo_has_turn_arround_experience_updates integer; addinfo_turnarround_experience_updates integer;
	addinfo_has_ipo_experience_updates integer; addinfo_ipo_experience_updates integer; addinfo_has_startup_experience_updates integer; addinfo_startup_experience_updates integer; addinfo_has_merger_acquisition_experience_updates integer; addinfo_merger_acquisition_experience_updates integer;
	addinfo_has_entrepenuer_experience_updates integer; addinfo_entrepenuer_experience_updates integer; addinfo_user_language_id_written_in_updates integer; addinfo_resume_origin_id_updates integer; addinfo_resume_origin_desc_updates integer; addinfo_etl_date_updates integer;
	BEGIN
			-- WANTS PERMANENTS UPDATES 
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_permanent = ST.wants_permanent
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_permanent <> RT.wants_permanent
					AND ST.wants_permanent IS NOT NULL;
					GET DIAGNOSTICS wants_permanent_updates = ROW_COUNT;
			-- WANTS CONTRACT UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_contract = ST.wants_contract
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_contract <> RT.wants_contract
					AND ST.wants_contract IS NOT NULL;
					GET DIAGNOSTICS wants_contract_updates = ROW_COUNT;
			--WANTS INTERN UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_intern = ST.wants_intern
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_intern <> RT.wants_intern
					AND ST.wants_intern IS NOT NULL;
					GET DIAGNOSTICS wants_intern_updates = ROW_COUNT;
			--WANTS TEMP UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_temp = ST.wants_temp
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_temp <> RT.wants_temp
					AND ST.wants_temp IS NOT NULL;
					GET DIAGNOSTICS wants_temp_updates = ROW_COUNT;
			--WANTS FULLTIME UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_fulltime = ST.wants_fulltime
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_fulltime <> RT.wants_fulltime
					AND ST.wants_fulltime IS NOT NULL;
					GET DIAGNOSTICS wants_fulltime_updates = ROW_COUNT;
			--WANTS PARTTIME UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_parttime = ST.wants_parttime
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_parttime <> RT.wants_parttime
					AND ST.wants_parttime IS NOT NULL;
					GET DIAGNOSTICS wants_parttime_updates = ROW_COUNT;
			--SALARY UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET salary = ST.salary
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.salary <> RT.salary
					AND ST.salary IS NOT NULL
					AND ST.salary <> '0';
					GET DIAGNOSTICS salary_updates = ROW_COUNT;
			--SALARY TYPE UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET salary_type_id = ST.salary_type_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.salary_type_id <> RT.salary_type_id
					AND ST.salary_type_id IS NOT NULL;
					GET DIAGNOSTICS salary_type_id_updates = ROW_COUNT;
			--CURRENCY ID UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET currency_id = ST.currency_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.currency_id <> RT.currency_id
					AND ST.currency_id IS NOT NULL;
					GET DIAGNOSTICS currency_id_updates = ROW_COUNT;
			--SITE LOCATION ID UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET site_location_id = ST.site_location_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.site_location_id <> RT.site_location_id
					AND ST.site_location_id IS NOT NULL;
					GET DIAGNOSTICS site_location_id_updates = ROW_COUNT;
			--COMMUTE DISTANCE UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET commute_distance = ST.commute_distance
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.commute_distance <> RT.commute_distance
					AND ST.commute_distance IS NOT NULL;
					GET DIAGNOSTICS commute_distance_updates = ROW_COUNT;
			--DISTANCE ID UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET distance_id = ST.distance_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.distance_id <> RT.distance_id
					AND ST.distance_id IS NOT NULL;
					GET DIAGNOSTICS distance_id_updates = ROW_COUNT;
			-- COMPANY SIZE ID UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET company_size_id = ST.company_size_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.company_size_id <> RT.company_size_id
					AND ST.company_size_id IS NOT NULL;
					GET DIAGNOSTICS company_size_id_updates = ROW_COUNT;
			-- CATEGORY ID UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET category_id = ST.category_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.category_id <> RT.category_id
					AND ST.category_id IS NOT NULL;
					GET DIAGNOSTICS category_id_updates = ROW_COUNT;
			-- RESUME TITLE UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET resume_title = trim(both ' ' from ST.resume_title)
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND trim(both ' ' from ST.resume_title) <> RT.resume_title
					AND trim(both ' ' from ST.resume_title) IS NOT NULL
					AND trim(both ' ' from ST.resume_title) <> '0'
					AND trim(both ' ' from ST.resume_title) <> 'No resume title' AND trim(both ' ' from ST.resume_title) <> '[No Title]';
					GET DIAGNOSTICS resume_title_updates = ROW_COUNT;
			-- DATE CREATED UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET date_created = ST.date_created
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.date_created <> RT.date_created
					AND ST.date_created IS NOT NULL;
					GET DIAGNOSTICS date_created_updates = ROW_COUNT;
			-- DATE MODIFIED UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET date_modified = ST.date_modified
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.date_modified <> RT.date_modified
					AND ST.date_modified IS NOT NULL;
					GET DIAGNOSTICS date_modified_updates = ROW_COUNT;
			-- WILL RELOCATE UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET will_relocate = ST.will_relocate
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.will_relocate <> RT.will_relocate
					AND ST.will_relocate IS NOT NULL;
					GET DIAGNOSTICS will_relocate_updates = ROW_COUNT;
			-- DATE EXPIRES UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET date_expires = ST.date_expires
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.date_expires <> RT.date_expires
					AND ST.date_expires IS NOT NULL;
					GET DIAGNOSTICS date_expires_updates = ROW_COUNT;
			-- CHANNEL ID UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET channel_id = ST.channel_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.channel_id <> RT.channel_id
					AND ST.channel_id IS NOT NULL;
					GET DIAGNOSTICS channel_id_updates = ROW_COUNT;
			-- ACTIVE UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET active = ST.active
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.active <> RT.active
					AND ST.active IS NOT NULL;
					GET DIAGNOSTICS active_updates = ROW_COUNT;
			-- DATE DELETED UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET date_deleted = ST.date_deleted
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.date_deleted <> RT.date_deleted
					AND ST.date_deleted IS NOT NULL;
					GET DIAGNOSTICS date_deleted_updates = ROW_COUNT;									
			-- BUILDER ID UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET builder_id = ST.builder_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.builder_id <> RT.builder_id
					AND ST.builder_id IS NOT NULL;
					GET DIAGNOSTICS builder_id_updates = ROW_COUNT;
			-- CREATED CHANNEL ID UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET created_channel_id = ST.created_channel_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.created_channel_id <> RT.created_channel_id
					AND ST.created_channel_id IS NOT NULL;
					GET DIAGNOSTICS created_channel_id_updates = ROW_COUNT;
			-- HOURLY UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET hourly = ST.hourly
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.hourly <> RT.hourly
					AND ST.hourly IS NOT NULL;
					GET DIAGNOSTICS hourly_updates = ROW_COUNT;
			-- WANTS PERDIEMS UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_perdiem = ST.wants_perdiem
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_perdiem <> RT.wants_perdiem
					AND ST.wants_perdiem IS NOT NULL;
					GET DIAGNOSTICS wants_perdiem_updates = ROW_COUNT;
			-- WANTS OVERTIME UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_overtime = ST.wants_overtime
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_overtime <> RT.wants_overtime
					AND ST.wants_overtime IS NOT NULL;
					GET DIAGNOSTICS wants_overtime_updates = ROW_COUNT;
			-- WANTS WEEKENDS UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET wants_weekends = ST.wants_weekends
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.wants_weekends <> RT.wants_weekends
					AND ST.wants_weekends IS NOT NULL;
					GET DIAGNOSTICS wants_weekends_updates = ROW_COUNT;
			-- PREFFER WEEKENDS UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET prefer_weekends = ST.prefer_weekends
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.prefer_weekends <> RT.prefer_weekends
					AND ST.prefer_weekends IS NOT NULL;
					GET DIAGNOSTICS prefer_weekends_updates = ROW_COUNT;
			-- DATE SEQUANTIAL UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET date_sequential = ST.date_sequential
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.date_sequential <> RT.date_sequential
					AND ST.date_sequential IS NOT NULL;
					GET DIAGNOSTICS date_sequential_updates = ROW_COUNT;
			-- SALARY FROM UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET salary_from = ST.salary_from
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.salary_from <> RT.salary_from
					AND ST.salary_from IS NOT NULL;
					GET DIAGNOSTICS salary_from_updates = ROW_COUNT;
			-- SALARY FROM NORMALISED UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET salary_from_normalised = ST.salary_from_normalised
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.salary_from_normalised <> RT.salary_from_normalised
					AND ST.salary_from_normalised IS NOT NULL;
					GET DIAGNOSTICS salary_from_normalised_updates = ROW_COUNT;
			-- ETL DATE UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET etl_date = ST.etl_date
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.etl_date <> RT.etl_date
					AND ST.etl_date IS NOT NULL;
					GET DIAGNOSTICS etl_date_updates = ROW_COUNT;
			-- DATASOURCE ID  UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET datasource_id = ST.datasource_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.datasource_id <> RT.datasource_id
					AND ST.datasource_id IS NOT NULL;
					GET DIAGNOSTICS datasource_id_updates = ROW_COUNT;															
			-- DATASOURCE ID  UPDATES
			UPDATE "MediaBay"."CLOUD_(03)_UserResumeDetails" RT 
					SET source_id = ST.source_id
			FROM "MediaBay"."CLOUD_STG_(03)_UserResumeDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.source_id <> RT.source_id
					AND ST.source_id IS NOT NULL;
					GET DIAGNOSTICS source_id_updates = ROW_COUNT;	
						-- HAS PL EXPERIENCE UPDATE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET has_pl_experience = ST.has_pl_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.has_pl_experience <> RT.has_pl_experience
					AND ST.has_pl_experience IS NOT NULL;
					GET DIAGNOSTICS addinfo_has_pl_experience_updates = ROW_COUNT;
			-- LARGEST BUDGET ANSWERED ID
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET largest_budget_answer_id = ST.largest_budget_answer_id
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.largest_budget_answer_id <> RT.largest_budget_answer_id
					AND ST.largest_budget_answer_id IS NOT NULL;
					GET DIAGNOSTICS addinfo_largest_budget_answer_id_updates = ROW_COUNT;
			-- NUMBER_PEOPLE_MANAGED_ANSWER_ID
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET number_people_managed_answer_id = ST.number_people_managed_answer_id
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.number_people_managed_answer_id <> RT.number_people_managed_answer_id
					AND ST.number_people_managed_answer_id IS NOT NULL;
					GET DIAGNOSTICS addinfo_number_people_managed_answer_id_updates = ROW_COUNT;
			-- HAS TURN ARROUND EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET has_turn_arround_experience = ST.has_turn_arround_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.has_turn_arround_experience <> RT.has_turn_arround_experience
					AND ST.has_turn_arround_experience IS NOT NULL;
					GET DIAGNOSTICS addinfo_has_turn_arround_experience_updates = ROW_COUNT;
			-- TURN ARROUND EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET turnarround_experience = ST.turnarround_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.turnarround_experience <> RT.turnarround_experience;
					GET DIAGNOSTICS addinfo_turnarround_experience_updates = ROW_COUNT;
			-- HAS IPO EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET has_ipo_experience = ST.has_ipo_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.has_ipo_experience <> RT.has_ipo_experience
					AND ST.has_ipo_experience IS NOT NULL;
					GET DIAGNOSTICS addinfo_has_ipo_experience_updates = ROW_COUNT;
			-- IPO EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET ipo_experience = ST.ipo_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.ipo_experience <> RT.ipo_experience;
					GET DIAGNOSTICS addinfo_ipo_experience_updates = ROW_COUNT;
			-- HAS STARTUP EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET has_startup_experience = ST.has_startup_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.has_startup_experience <> RT.has_startup_experience
					AND ST.has_startup_experience IS NOT NULL;
					GET DIAGNOSTICS addinfo_has_startup_experience_updates = ROW_COUNT;
			-- STARTUP EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET startup_experience = ST.startup_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.startup_experience <> RT.startup_experience;
					GET DIAGNOSTICS addinfo_startup_experience_updates = ROW_COUNT;
			-- HAS M&A EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET has_merger_acquisition_experience = ST.has_merger_acquisition_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.has_merger_acquisition_experience <> RT.has_merger_acquisition_experience
					AND ST.has_merger_acquisition_experience IS NOT NULL;
					GET DIAGNOSTICS addinfo_has_merger_acquisition_experience_updates = ROW_COUNT;
			-- M&A EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET merger_acquisition_experience = ST.merger_acquisition_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.merger_acquisition_experience <> RT.merger_acquisition_experience;
					GET DIAGNOSTICS addinfo_merger_acquisition_experience_updates = ROW_COUNT;
			-- HAS ENTREPENEUR EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET has_entrepenuer_experience = ST.has_entrepenuer_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.has_entrepenuer_experience <> RT.has_entrepenuer_experience
					AND ST.has_entrepenuer_experience IS NOT NULL;
					GET DIAGNOSTICS addinfo_has_entrepenuer_experience_updates = ROW_COUNT;
			-- ENTREPENEUR EXPERIENCE
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET entrepenuer_experience = ST.entrepenuer_experience
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.entrepenuer_experience <> RT.entrepenuer_experience;
					GET DIAGNOSTICS addinfo_entrepenuer_experience_updates = ROW_COUNT;
			-- LANGUAGE ID WRITTEN IN
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET user_language_id_written_in = ST.user_language_id_written_in
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.user_language_id_written_in <> RT.user_language_id_written_in
					AND ST.user_language_id_written_in IS NOT NULL
					AND ST.user_language_id_written_in <> '0';
					GET DIAGNOSTICS addinfo_user_language_id_written_in_updates = ROW_COUNT;
			-- RESUME ORIGIN ID
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET resume_origin_id = ST.resume_origin_id
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.resume_origin_id <> RT.resume_origin_id;
					GET DIAGNOSTICS addinfo_resume_origin_id_updates = ROW_COUNT;
			-- RESUME ORIGIN DESC
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET resume_origin_desc = ST.resume_origin_desc
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.resume_origin_desc <> RT.resume_origin_desc;
					GET DIAGNOSTICS addinfo_resume_origin_desc_updates = ROW_COUNT;
			-- ETL DATE 
			UPDATE "MediaBay"."CLOUD_(03.1)_ResumeAdditionalInfoDetails" RT 
					SET etl_date = ST.etl_date
			FROM "MediaBay"."CLOUD_STG_(03.1)_ResumeAdditionalInfoDetails" ST
			WHERE
					RT.resume_id= ST.resume_id
					AND ST.etl_date <> RT.etl_date
					AND ST.etl_date IS NOT NULL;
					GET DIAGNOSTICS addinfo_etl_date_updates = ROW_COUNT;		
			--GET RESULTS IN THE QUERY
			RETURN QUERY SELECT wants_permanent_updates, wants_contract_updates, wants_intern_updates, wants_temp_updates, wants_fulltime_updates, wants_parttime_updates, salary_updates, salary_type_id_updates, currency_id_updates, site_location_id_updates, 
			commute_distance_updates, distance_id_updates, company_size_id_updates, category_id_updates, resume_title_updates, date_created_updates, date_modified_updates, will_relocate_updates, date_expires_updates, channel_id_updates, active_updates, date_deleted_updates, 
			builder_id_updates, created_channel_id_updates, hourly_updates, wants_perdiem_updates, wants_overtime_updates, wants_weekends_updates, prefer_weekends_updates, date_sequential_updates, salary_from_updates, salary_from_normalised_updates, etl_date_updates, datasource_id_updates, source_id_updates,
			addinfo_has_pl_experience_updates, addinfo_largest_budget_answer_id_updates, addinfo_number_people_managed_answer_id_updates, addinfo_has_turn_arround_experience_updates, addinfo_turnarround_experience_updates,
			addinfo_has_ipo_experience_updates, addinfo_ipo_experience_updates, addinfo_has_startup_experience_updates, addinfo_startup_experience_updates, addinfo_has_merger_acquisition_experience_updates, addinfo_merger_acquisition_experience_updates,
			addinfo_has_entrepenuer_experience_updates, addinfo_entrepenuer_experience_updates, addinfo_user_language_id_written_in_updates, addinfo_resume_origin_id_updates, addinfo_resume_origin_desc_updates, addinfo_etl_date_updates;
	END;
$$;

