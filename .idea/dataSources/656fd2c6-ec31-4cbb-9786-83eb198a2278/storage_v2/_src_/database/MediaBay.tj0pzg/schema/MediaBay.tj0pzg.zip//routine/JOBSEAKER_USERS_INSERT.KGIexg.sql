CREATE FUNCTION "JOBSEAKER_USERS_INSERT"()
  RETURNS TABLE(user_info_details_inserted integer, user_email_statuses_inserted integer, user_additional_info_inserted integer, user_optional_info_inserted integer, user_legal_status_inserts integer, user_work_status_inserts integer, user_phone_details_inserts integer, user_address_inserts integer, user_language_inserts integer, user_education_inserted integer, user_login_details_affected integer)
LANGUAGE plpgsql
AS $$
DECLARE
		user_info_details_inserted integer; user_email_statuses_inserted integer; user_additional_info_inserted integer; user_optional_info_inserted integer; user_legal_status_inserts integer; user_work_status_inserts integer; user_phone_details_inserts integer; user_address_inserts integer; user_language_inserts integer; user_education_inserted integer; user_login_details_affected integer;
		BEGIN
				--"MediaBay"."JS_U_(01)_UserInfoDetails"
				INSERT INTO "MediaBay"."JS_U_(01)_UserInfoDetails" (user_id, username, name_prefix_id, first_name, middle_name, last_name, name_suffix, email_address, country_id, state_id, us_zip5, location_id, confidential, disabled, channel_id, career_level_id, available_time_id,
				available_day, available_month, available_year, company, date_created, date_modified, date_deleted, etl_date, created_channel_id)
				SELECT DISTINCT ON (user_id) user_id, username, name_prefix_id, initcap (trim(both ' ' from first_name)), initcap(trim(both ' ' from middle_name)), initcap(trim(both ' ' from last_name)), trim(both ' ' from name_suffix), trim(both ' ' from email_address), country_id, 
				state_id, us_zip5, location_id, confidential, disabled, channel_id, career_level_id, available_time_id, available_day, available_month, available_year, initcap(trim(both ' ' from company)), date_created, date_modified, date_deleted, etl_date, created_channel_id
				FROM "MediaBay"."JS_U_STG_(01)_UserInfoDetails"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS user_info_details_inserted = ROW_COUNT;
				--"MediaBay"."JS_U_(01.1)_UserEmailStatus"
				DELETE FROM "MediaBay"."JS_U_STG_(01.1)_UserEmailStatus" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE ST.user_id = RT.user_id);
				INSERT INTO "MediaBay"."JS_U_(01.1)_UserEmailStatus" (user_id, email_address_status_id, date_created, date_modified, datasource_id)
				SELECT DISTINCT ON (user_id) user_id, email_address_status_id, date_created, date_modified, datasource_id
				FROM "MediaBay"."JS_U_STG_(01.1)_UserEmailStatus"
				ON CONFLICT ON CONSTRAINT user_email_status_pkey DO UPDATE
					SET email_address_status_id = EXCLUDED.email_address_status_id,
						date_modified = EXCLUDED.date_modified;
				GET DIAGNOSTICS user_email_statuses_inserted = ROW_COUNT;
				--"MediaBay"."JS_U_(01.2)_UserAdditionalInfo"
				DELETE FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo" RT1 WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE RT1.user_id = RT.user_id);
				INSERT INTO "MediaBay"."JS_U_(01.2)_UserAdditionalInfo" (user_id, contact_prefered_format_id, year_experience_id, us_military_involvement_id, date_modified, years_user_exp_id_project_leadership, year_user_exp_id_management, local_location_id, datasource_id)
				SELECT DISTINCT ON (user_id) user_id, contact_prefered_format_id, year_experience_id, us_military_involvement_id, date_modified, years_user_exp_id_project_leadership, year_user_exp_id_management, local_location_id, datasource_id
				FROM "MediaBay"."JS_U_STG_(01.2)_UserAdditionalInfo"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS user_additional_info_inserted = ROW_COUNT;
				--"MediaBay"."JS_U_(01.3)_UserOptionalInfo"
				DELETE FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo" RT1 WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE RT1.user_id = RT.user_id);
				INSERT INTO "MediaBay"."JS_U_(01.3)_UserOptionalInfo" (user_id, country_id, dob_day, dob_month, dob_year, gender_id, ethnicity_id, date_modified, purged, disability, disability_desc, ex_convict, vectim_of_terrorism, employment_equity_candidate, new_customer, target_product_type_id, karma_company_size_id, copmany_group_id, datasource_id)
				SELECT DISTINCT ON (user_id) user_id, country_id, dob_day, dob_month, dob_year, gender_id, ethnicity_id, date_modified, purged, disability, disability_desc, ex_convict, vectim_of_terrorism, employment_equity_candidate, new_customer, target_product_type_id, karma_company_size_id, copmany_group_id, datasource_id
				FROM "MediaBay"."JS_U_STG_(01.3)_UserOptionalInfo"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS user_optional_info_inserted = ROW_COUNT;
				--"MediaBay"."JS_U_(01.4)_UserLegalStatus"
				DELETE FROM "MediaBay"."JS_U_STG_(01.4)_UserLegalStatus" RT1 WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE RT1.user_id = RT.user_id);
				INSERT INTO "MediaBay"."JS_U_(01.4)_UserLegalStatus" (user_id, country_id, legal_status_id, datasource_id, date_created, etl_date)
				SELECT DISTINCT ON (user_id, country_id) user_id, country_id, legal_status_id, datasource_id, date_created, etl_date
				FROM "MediaBay"."JS_U_STG_(01.4)_UserLegalStatus"
				ON CONFLICT ON CONSTRAINT user_legal_status_pkey DO UPDATE
					SET country_id = EXCLUDED.country_id,
						legal_status_id = EXCLUDED.legal_status_id,
						date_created = EXCLUDED.date_created;
				GET DIAGNOSTICS user_legal_status_inserts = ROW_COUNT;
				--"MediaBay"."JS_U_(01.5)_UserWorkStatus"
				DELETE FROM "MediaBay"."JS_U_STG_(01.5)_UserWorkStatus" RT1 WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE RT1.user_id = RT.user_id);
				INSERT INTO "MediaBay"."JS_U_(01.5)_UserWorkStatus" (user_id, country_id, work_status_id, date_created, datasource_id)
				SELECT DISTINCT ON (user_id, country_id) user_id, country_id, work_status_id, date_created, datasource_id
				FROM "MediaBay"."JS_U_STG_(01.5)_UserWorkStatus"
				ON CONFLICT ON CONSTRAINT user_work_status_pkey DO UPDATE
						SET country_id = EXCLUDED.country_id,
						        work_status_id = EXCLUDED.work_status_id,
							 date_created = EXCLUDED.date_created;
				GET DIAGNOSTICS user_work_status_inserts = ROW_COUNT;
				--"MediaBay"."JS_U_(02)_UserPhoneDetails"
				DELETE FROM "MediaBay"."JS_U_STG_(02)_UserPhoneDetails" WHERE LENGTH(phone_number) < 5;
				DELETE FROM "MediaBay"."JS_U_STG_(02)_UserPhoneDetails" WHERE STRPOS(LTRIM(RTRIM(UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone_number,'=',''),'X',''),'*',''),'+',''),'(',''),')',''),'.',''),'/',''),'-',''),' ','')))), '99999') > 0;
				DELETE FROM "MediaBay"."JS_U_STG_(02)_UserPhoneDetails" WHERE STRPOS(LTRIM(RTRIM(UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone_number,'=',''),'X',''),'*',''),'+',''),'(',''),')',''),'.',''),'/',''),'-',''),' ','')))), '00000') > 0;
				DELETE FROM "MediaBay"."JS_U_STG_(02)_UserPhoneDetails" WHERE STRPOS(LTRIM(RTRIM(UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone_number,'=',''),'X',''),'*',''),'+',''),'(',''),')',''),'.',''),'/',''),'-',''),' ','')))), 'XXXX') > 0;
				INSERT INTO "MediaBay"."JS_U_(02)_UserPhoneDetails" (user_id, phone_type_id, phone_number, preferred_method, date_modified, etl_date, datasource_id)
				SELECT DISTINCT ON (user_id, phone_type_id, datasource_id) user_id, phone_type_id, phone_number, preferred_method, date_modified, etl_date, datasource_id
				FROM "MediaBay"."JS_U_STG_(02)_UserPhoneDetails"
				ON CONFLICT ON CONSTRAINT user_phone_number_pkey DO UPDATE
						SET phone_number = EXCLUDED.phone_number, 
							 preferred_method = EXCLUDED.preferred_method, 
							date_modified = EXCLUDED.date_modified, 
							etl_date = EXCLUDED.etl_date;
				GET DIAGNOSTICS user_phone_details_inserts = ROW_COUNT;
				--"MediaBay"."JS_U_(02)_UserPhoneDetails"
				INSERT INTO "MediaBay"."JS_U_(02)_UserPhoneDetails" (user_id, phone_type_id, phone_number, preferred_method, date_modified, etl_date, datasource_id)
				SELECT DISTINCT ON (user_id, phone_type_id, datasource_id) user_id, phone_type_id, phone_number, preferred_method, date_modified, etl_date, datasource_id
				FROM "MediaBay"."JS_U_STG_(02)_UserPhoneDetails"
				ON CONFLICT ON CONSTRAINT user_phone_number_pkey DO UPDATE
						SET phone_type_id = EXCLUDED.phone_type_id,
							phone_number = EXCLUDED.phone_number,
							preferred_method = EXCLUDED.preferred_method,
							date_modified = EXCLUDED.date_modified,
							etl_date = EXCLUDED.etl_date;
				--"MediaBay"."JS_U_(03)_UserAddressDetails"
				DELETE FROM "MediaBay"."JS_U_STG_(03)_UserAddressDetails" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE ST.user_id = RT.user_id);
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET address1 = NULL WHERE address1 = '0';
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET address2 = NULL WHERE address2 = '0';
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET city = NULL WHERE city = '0';
				UPDATE "MediaBay"."JS_U_STG_(03)_UserAddressDetails" SET postal_code = NULL WHERE postal_code = '0';
				INSERT INTO "MediaBay"."JS_U_(03)_UserAddressDetails" (user_id, address_type_id, verified_id, address1, address2, city, postal_code, ref_geo_id, preferred_method, date_modified, datasource_id)
				SELECT DISTINCT ON (user_id, address_type_id, datasource_id) user_id, address_type_id, verified_id, initcap(trim(both ' ' from address1)), initcap(trim(both ' ' from address2)), initcap(trim(both ' ' from city)), trim(both ' ' from postal_code), ref_geo_id, preferred_method, date_modified, datasource_id
				FROM "MediaBay"."JS_U_STG_(03)_UserAddressDetails" ST
				ON CONFLICT ON CONSTRAINT user_address_pkey DO UPDATE
					SET address_type_id = EXCLUDED.address_type_id,
						verified_id = EXCLUDED.verified_id,
						address1 = initcap(trim(both ' ' from EXCLUDED.address1)),
						address2 = initcap(trim(both ' ' from EXCLUDED.address2)),
						city = initcap(trim(both ' ' from EXCLUDED.city)),
						postal_code = trim(both ' ' from EXCLUDED.postal_code),
						ref_geo_id = EXCLUDED.ref_geo_id,
						preferred_method = EXCLUDED.preferred_method,
						date_modified = EXCLUDED.date_modified;
				GET DIAGNOSTICS user_address_inserts = ROW_COUNT;
				--"MediaBay"."JS_U_(04)_UserLanguageDetails"
				DELETE FROM "MediaBay"."JS_U_STG_(04)_UserLanguageDetails" RT1 WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE RT1.user_id = RT.user_id);
				INSERT INTO "MediaBay"."JS_U_(04)_UserLanguageDetails" (user_id, language_id, language_proficiency_id, date_created, datasource_id)
				SELECT DISTINCT ON (user_id, language_id, datasource_id) user_id, language_id, language_proficiency_id, date_created, datasource_id
				FROM "MediaBay"."JS_U_STG_(04)_UserLanguageDetails"
				ON CONFLICT ON CONSTRAINT user_language_pkey DO UPDATE
					SET language_id = EXCLUDED.language_id,
						 language_proficiency_id = EXCLUDED.language_proficiency_id,
						 date_created = EXCLUDED.date_created;
				GET DIAGNOSTICS user_language_inserts = ROW_COUNT;
				--"MediaBay"."JS_U_(05)_UserEducationDetails"
				DELETE FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE ST.user_id = RT.user_id);
				INSERT INTO "MediaBay"."JS_U_(05)_UserEducationDetails" (user_education_id, user_id, education_level_id, ref_school_id, start_month, start_year, completed_day, completed_month, completed_year, education_subject, education_summary, gpa, city, state, country_id, resume_education_id, resume_id, date_created, date_modified, date_deleted, etl_date, datasource_id)
				SELECT DISTINCT ON (user_education_id) user_education_id, user_id, education_level_id, ref_school_id, start_month, start_year, completed_day, completed_month, completed_year, trim(both ' ' from education_subject), trim(both ' ' from education_summary), gpa, initcap(trim(both ' ' from city)), initcap(trim(both ' ' from state)), country_id, resume_education_id, resume_id, date_created, date_modified, date_deleted, etl_date, datasource_id
				FROM "MediaBay"."JS_U_STG_(05)_UserEducationDetails"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS user_education_inserted = ROW_COUNT;
				--"MediaBay"."JS_U_(20)_UserLoginDetails"
				DELETE FROM "MediaBay"."JS_U_STG_(20)_UserLoginDetails" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."JS_U_(01)_UserInfoDetails" RT WHERE ST.user_id = RT.user_id);
				INSERT INTO "MediaBay"."JS_U_(20)_UserLoginDetails" (year_id, month_id, day_id, user_id, ip1, ip2, ip3, ip4, channel_id, logins, webdate_id, datasource_id)
				SELECT DISTINCT ON (year_id, month_id, day_id, user_id, ip1, ip2, ip3, ip4, channel_id) year_id, month_id, day_id, user_id, ip1, ip2, ip3, ip4, channel_id, logins, webdate_id, datasource_id
				FROM "MediaBay"."JS_U_STG_(20)_UserLoginDetails"
				ON CONFLICT ON CONSTRAINT user_login_details_pkey DO UPDATE
						SET logins = EXCLUDED.logins, 
							webdate_id = EXCLUDED.webdate_id;
				GET DIAGNOSTICS user_login_details_affected = ROW_COUNT;
				RETURN QUERY SELECT user_info_details_inserted, user_email_statuses_inserted, user_additional_info_inserted, user_optional_info_inserted, user_legal_status_inserts, user_work_status_inserts, user_phone_details_inserts, user_address_inserts, user_language_inserts, user_education_inserted, user_login_details_affected;
		END;

$$;

