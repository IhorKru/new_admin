CREATE FUNCTION "RECRUITER_DATA_UPDATE"()
  RETURNS TABLE(recruiter_disabled_updates integer, recruiter_email_address_updates integer, recruiter_city_updates integer, recruiter_state_id_updates integer, recruiter_postal_code_updates integer, recruiter_country_id_updates integer, recruiter_channel_id_updates integer, recruiter_company_id_updates integer, recruiter_email_address_resumes_updates integer, recruiter_auto_user_updates integer, recruiter_edit_jobs_updates integer, recruiter_edit_user_profile_updates integer, recruiter_manage_company_job_updates integer, recruiter_manage_company_letter_updates integer, recruiter_manage_company_users_updates integer, recruiter_manage_corp_jobs_updates integer, recruiter_manage_corp_users_updates integer, recruiter_manage_jobs_updates integer, recruiter_manage_letters_updates integer, recruiter_pre_screen_updates integer, recruiter_post_jobs_updates integer, recruiter_search_resumes_updates integer, recruiter_max_recruiter_agents_updates integer, recruiter_date_expired_updates integer, recruiter_resume_format_updates integer, recruiter_first_name_updates integer, recruiter_last_name_updates integer, recruiter_address1_updates integer, recruiter_address2_updates integer, recruiter_daytime_phone_updates integer, recruiter_evening_phone_updates integer, recruiter_mobile_phone_updates integer, recruiter_fax_updates integer, recruiter_pager_updates integer, recruiter_confidential_updates integer, recruiter_company_updates integer, recruiter_career_level_id_updates integer, recruiter_available_time_id_updates integer, recruiter_available_day_updates integer, recruiter_available_month_updates integer, recruiter_available_year_updates integer, recruiter_location_id_updates integer, recruiter_date_modified_updates integer, recruiter_ats_permissions_updates integer, recruiter_middle_name_updates integer, recruiter_name_prefix_id_updates integer, recruiter_name_suffix_updates integer, recruiter_user_date_modified_updates integer, recruiter_resume_notes_updates integer, recruiter_resume_routing_updates integer, recruiter_application_resume_format_updates integer, recruiter_created_channel_id_updates integer, recruiter_recruiter_job_title_updates integer, recruiter_etl_date_updates integer, recruiter_datasource_id_updates integer, "recruiter_​eorder_tax_amount_updates" integer, "recruiter_​​eorder_total_amount_updates" integer, "recruiter_​po_number_updates" integer, "recruiter_​​paid_updates" integer, "recruiter_​create_amount_updates" integer, "recruiter_​member_shipin_cart_updates" integer, "recruiter_​​total_jobs_in_cart_updates" integer, "recruiter_​total_resumes_in_cart_updates" integer, "recruiter_​​channel_id_updates" integer, "recruiter_​​​abandoned_cart_updates" integer, "recruiter_​​​date_modified_updates" integer, "recruiter_​​​​bill_back_info_updates" integer, recruiter_billing_name_prefix_id_updates integer, recruiter_billing_first_name_updates integer, recruiter_billing_middle_name_updates integer, recruiter_billling_last_name_updates integer, recruiter_billing_company_updates integer, recruiter_billing_address1_updates integer, creduiter_billing_address2_updates integer, recruiter_billing_email_address_updates integer, recruiter_billing_city_updates integer, recruiter_billing_state_id_updates integer, recruiter_billing_zip_code_updates integer, recruiter_billing_phone_number_updates integer, recruiter_billing_fax_number_updates integer, recruiter_billing_po_number_updates integer, recruiter_billing_payment_type_id_updates integer, recruiter_billing_paypal_token_updates integer, recruiter_billing_paypal_payer_id_updates integer, recruiter_billing_bank_account_type_id_updates integer, recruiter_billing_bank_routing_number_updates integer, recruiter_billing_bank_account_number_updates integer, recruiter_billing_split_billing_updates integer, recruiter_billing_country_id_updates integer, recruiter_billing_datasource_id_updates integer, recruiter_abb_cart_user_id_updates integer, recruiter_abb_cart_cart_id_updates integer, recruiter_abb_cart_channel_id_updates integer, recruiter_abb_cart_application_id_updates integer, recruiter_abb_cart_first_name_updates integer, recruiter_abb_cart_middle_name_updates integer, recruiter_abb_cart_last_name_updates integer, recruiter_abb_cart_company_name_updates integer, recruiter_abb_cart_address1_updates integer, recruiter_abb_cart_address2_updates integer, recruiter_abb_cart_email_address_updates integer, recruiter_abb_cart_company_id_updates integer, recruiter_abb_cart_date_expired_updates integer, recruiter_abb_cart_disabled_updates integer, recruiter_abb_cart_state_id_updatest integer, recruiter_abb_cart_country_id_updates integer, recruiter_abb_cart_confidential_updates integer, recruiter_abb_cart_company_updates integer, recruiter_abb_cart_date_last_login_updates integer, recruiter_abb_cart_location_id_updates integer, recruiter_abb_cart_name_prefix_id_updates integer, recruiter_abb_cart_name_suffix_updates integer, recruiter_abb_cart_city_updates integer, recruiter_abb_cart_postal_code_updates integer, recruiter_abb_cart_daytime_phone_updates integer, recruiter_abb_cart_evening_phone_updates integer, recruiter_abb_cart_mobile_phone_updates integer, recruiter_abb_cart_fax_updates integer, recruiter_abb_cart_pager_updates integer, recruiter_abb_cart_date_modified_updates integer, recruiter_abb_cart_etl_date_updates integer, recruiter_abb_cart_datasource_id_updates integer)
LANGUAGE plpgsql
AS $$
DECLARE
		--"MediaBay"."R_(01.1)_RecruiterAdditionalInfo"
		recruiter_disabled_updates integer; recruiter_email_address_updates integer; recruiter_city_updates integer; recruiter_state_id_updates integer; recruiter_postal_code_updates integer; recruiter_country_id_updates integer; recruiter_channel_id_updates integer; recruiter_company_id_updates integer;
		recruiter_email_address_resumes_updates integer; recruiter_auto_user_updates integer; recruiter_edit_jobs_updates integer; recruiter_edit_user_profile_updates integer; recruiter_manage_company_job_updates integer; recruiter_manage_company_letter_updates integer; recruiter_manage_company_users_updates integer;
		recruiter_manage_corp_jobs_updates integer; recruiter_manage_corp_users_updates integer; recruiter_manage_jobs_updates integer; recruiter_manage_letters_updates integer; recruiter_pre_screen_updates integer; recruiter_post_jobs_updates integer; recruiter_search_resumes_updates integer;
		recruiter_max_recruiter_agents_updates integer; recruiter_date_expired_updates integer; recruiter_resume_format_updates integer; recruiter_first_name_updates integer; recruiter_last_name_updates integer; recruiter_address1_updates integer; recruiter_address2_updates integer; recruiter_daytime_phone_updates integer;
		recruiter_evening_phone_updates integer; recruiter_mobile_phone_updates integer; recruiter_fax_updates integer; recruiter_pager_updates integer; recruiter_confidential_updates integer; recruiter_company_updates integer; recruiter_career_level_id_updates integer;
		recruiter_available_time_id_updates integer; recruiter_available_day_updates integer; recruiter_available_month_updates integer; recruiter_available_year_updates integer; recruiter_location_id_updates integer; recruiter_date_modified_updates integer; recruiter_ats_permissions_updates integer;
		recruiter_middle_name_updates integer; recruiter_name_prefix_id_updates integer; recruiter_name_suffix_updates integer; recruiter_user_date_modified_updates integer; recruiter_resume_notes_updates integer; recruiter_resume_routing_updates integer; recruiter_application_resume_format_updates integer;
		recruiter_created_channel_id_updates integer; recruiter_recruiter_job_title_updates integer; recruiter_etl_date_updates integer; recruiter_datasource_id_updates integer;
		--"MediaBay"."R_(02)_RecruiterShoppingCartDetails"
		recruiter_​eorder_tax_amount_updates integer; recruiter_​​eorder_total_amount_updates integer; recruiter_​po_number_updates integer; recruiter_​​paid_updates integer; recruiter_​create_amount_updates integer; recruiter_​member_shipin_cart_updates integer; recruiter_​​total_jobs_in_cart_updates integer; recruiter_​total_resumes_in_cart_updates integer; recruiter_​​channel_id_updates integer;
		recruiter_​​​abandoned_cart_updates integer; recruiter_​​​date_modified_updates integer; recruiter_​​​​bill_back_info_updates integer;
		--"MediaBay"."R_(02.1)_RecruiterShoppingCartUser"
		recruiter_​​​​user_channel_id_updates integer; recruiter_user_channel_id_updates integer; recruiter_user_application_id_updates integer; recruiter_user_cart_id_updates integer; recruiter_user_datasource_id_updates integer;
		--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"
		recruiter_contact_name_prefix_id_updates integer; recruiter_contact_​job_title_id_updates integer; recruiter_contact_​​first_name_updates integer; recruiter_contact_​middle_name_updates integer;
		recruiter_contact_last_name_updates integer; recruiter_contact_​company_name_updates integer; recruiter_contact_​address1_updates integer; recruiter_contact_​address2_updates integer; recruiter_contact_​​email_address_updates integer;
		recruiter_contact_​​city_updates integer; recruiter_contact_​​​state_id_updates integer; recruiter_contact_​​​​zip_code_updates integer; recruiter_contact_​​​​​phone_number_updates integer; 
		recruiter_contact_​​​​​​fax_number_updates integer; recruiter_contact_​how_header_id_updates integer; recruiter_contact_​​allow_marketing_updates integer; recruiter_contact_​​​date_modified_updates integer;
		recruiter_contact_​job_function_id_updates integer; recruiter_contact_​​karma_company_size_id_updates integer; recruiter_contact_​​​company_id_updates integer;
		--"MediaBay"."R_(02.3)_RecruiterShoppingCartBilling"
		recruiter_billing_name_prefix_id_updates integer; recruiter_billing_first_name_updates integer; recruiter_billing_middle_name_updates integer; recruiter_billling_last_name_updates integer; recruiter_billing_company_updates integer; recruiter_billing_address1_updates integer; creduiter_billing_address2_updates integer;
		recruiter_billing_email_address_updates integer; recruiter_billing_city_updates integer; recruiter_billing_state_id_updates integer; recruiter_billing_zip_code_updates integer; recruiter_billing_phone_number_updates integer; recruiter_billing_fax_number_updates integer; recruiter_billing_po_number_updates integer;
		recruiter_billing_payment_type_id_updates integer; recruiter_billing_paypal_token_updates integer; recruiter_billing_paypal_payer_id_updates integer; recruiter_billing_bank_account_type_id_updates integer; recruiter_billing_bank_routing_number_updates integer; recruiter_billing_bank_account_number_updates integer; 
		recruiter_billing_split_billing_updates integer; recruiter_billing_country_id_updates integer; recruiter_billing_datasource_id_updates integer;
		--"MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart"
		recruiter_abb_cart_user_id_updates integer; recruiter_abb_cart_cart_id_updates integer; recruiter_abb_cart_channel_id_updates integer; recruiter_abb_cart_application_id_updates integer; recruiter_abb_cart_first_name_updates integer; recruiter_abb_cart_middle_name_updates integer; recruiter_abb_cart_last_name_updates integer;
		recruiter_abb_cart_company_name_updates integer; recruiter_abb_cart_address1_updates integer; recruiter_abb_cart_address2_updates integer; recruiter_abb_cart_email_address_updates integer; recruiter_abb_cart_company_id_updates integer; recruiter_abb_cart_date_expired_updates integer; recruiter_abb_cart_disabled_updates integer;
		recruiter_abb_cart_state_id_updatest integer; recruiter_abb_cart_country_id_updates integer; recruiter_abb_cart_confidential_updates integer; recruiter_abb_cart_company_updates integer; recruiter_abb_cart_date_last_login_updates integer; recruiter_abb_cart_location_id_updates integer; recruiter_abb_cart_name_prefix_id_updates integer;
		recruiter_abb_cart_name_suffix_updates integer; recruiter_abb_cart_city_updates integer; recruiter_abb_cart_postal_code_updates integer; recruiter_abb_cart_daytime_phone_updates integer; recruiter_abb_cart_evening_phone_updates integer; recruiter_abb_cart_mobile_phone_updates integer; recruiter_abb_cart_fax_updates integer;
		recruiter_abb_cart_pager_updates integer; recruiter_abb_cart_date_modified_updates integer; recruiter_abb_cart_etl_date_updates integer; recruiter_abb_cart_datasource_id_updates integer;
		BEGIN
			--"MediaBay"."R_(01)_RecruiterDetails"--disabled
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET disabled = ST.disabled
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.disabled <> RT.disabled
					AND ST.disabled IS NOT NULL;
				GET DIAGNOSTICS recruiter_disabled_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--email_address
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET email_address = trim(both ' ' from ST.email_address)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.email_address) <> RT.email_address
					AND trim(both ' ' from ST.email_address) IS NOT NULL;
				GET DIAGNOSTICS recruiter_email_address_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--city
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET city = initcap(trim(both ' ' from ST.city))
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND initcap(trim(both ' ' from ST.city)) <> RT.city
					AND initcap(trim(both ' ' from ST.city)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_city_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--state_id 
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET state_id = ST.state_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.state_id <> RT.state_id
					AND ST.state_id IS NOT NULL
					AND ST.state_id <> '0'
					AND ST.state_id <> '-1';
				GET DIAGNOSTICS recruiter_state_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--postal_code
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET postal_code = trim(both ' ' from ST.postal_code)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.postal_code) <> RT.postal_code
					AND trim(both ' ' from ST.postal_code) IS NOT NULL;
				GET DIAGNOSTICS recruiter_postal_code_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--country_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET country_id = ST.country_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.country_id <> RT.country_id
					AND ST.country_id IS NOT NULL
					AND ST.company_id <> '0';
				GET DIAGNOSTICS recruiter_country_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--channel_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET channel_id = ST.channel_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.channel_id <> RT.channel_id
					AND ST.channel_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_channel_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--company_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET company_id = ST.company_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.company_id <> RT.company_id
					AND ST.company_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_company_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--email_address_resumes
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET email_address_resumes = trim(both ' ' from ST.email_address_resumes)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.email_address_resumes) <> RT.email_address_resumes
					AND trim(both ' ' from ST.email_address_resumes) IS NOT NULL;
				GET DIAGNOSTICS recruiter_email_address_resumes_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--auto_user
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET auto_user = ST.auto_user
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.auto_user <> RT.auto_user
					AND ST.auto_user IS NOT NULL;
				GET DIAGNOSTICS recruiter_auto_user_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--edit_jobs
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET edit_jobs = ST.edit_jobs
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.edit_jobs <> RT.edit_jobs
					AND ST.edit_jobs IS NOT NULL;
				GET DIAGNOSTICS recruiter_edit_jobs_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--edit_user_profile
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET edit_user_profile = ST.edit_user_profile
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.edit_user_profile <> RT.edit_user_profile
					AND ST.edit_user_profile IS NOT NULL;
				GET DIAGNOSTICS recruiter_edit_user_profile_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--manage_company_job
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET manage_company_job = ST.manage_company_job
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.manage_company_job <> RT.manage_company_job
					AND ST.manage_company_job IS NOT NULL;
				GET DIAGNOSTICS recruiter_manage_company_job_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--manage_company_letter
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET manage_company_letter = ST.manage_company_letter
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
					WHERE
					RT.user_id = ST.user_id
					AND ST.manage_company_letter <> RT.manage_company_letter
					AND ST.manage_company_letter IS NOT NULL;
				GET DIAGNOSTICS recruiter_manage_company_letter_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--manage_company_users
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET manage_company_users = ST.manage_company_users
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.manage_company_users <> RT.manage_company_users
					AND ST.manage_company_users IS NOT NULL;
				GET DIAGNOSTICS recruiter_manage_company_users_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--manage_corp_jobs
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET manage_corp_jobs = ST.manage_corp_jobs
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.manage_corp_jobs <> RT.manage_corp_jobs
					AND ST.manage_corp_jobs IS NOT NULL;
				GET DIAGNOSTICS recruiter_manage_corp_jobs_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--manage_corp_users
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET manage_corp_users = ST.manage_corp_users
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.manage_corp_users <> RT.manage_corp_users
					AND ST.manage_corp_users IS NOT NULL;
				GET DIAGNOSTICS recruiter_manage_corp_users_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--manage_jobs
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET manage_jobs = ST.manage_jobs
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.manage_jobs <> RT.manage_jobs
					AND ST.manage_jobs IS NOT NULL;
				GET DIAGNOSTICS recruiter_manage_jobs_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--manage_letters
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET manage_letters = ST.manage_letters
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.manage_letters <> RT.manage_letters
					AND ST.manage_letters IS NOT NULL;
				GET DIAGNOSTICS recruiter_manage_letters_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--pre_screen
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET pre_screen = ST.pre_screen
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.pre_screen <> RT.pre_screen
					AND ST.pre_screen IS NOT NULL;
				GET DIAGNOSTICS recruiter_pre_screen_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--post_jobs
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET post_jobs = ST.post_jobs
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.post_jobs <> RT.post_jobs
					AND ST.post_jobs IS NOT NULL;
				GET DIAGNOSTICS recruiter_post_jobs_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--search_resumes
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET search_resumes = ST.search_resumes
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.search_resumes <> RT.search_resumes
					AND ST.search_resumes IS NOT NULL;
				GET DIAGNOSTICS recruiter_search_resumes_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--max_recruiter_agents
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET max_recruiter_agents = ST.max_recruiter_agents
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.max_recruiter_agents <> RT.max_recruiter_agents
					AND ST.max_recruiter_agents IS NOT NULL;
				GET DIAGNOSTICS recruiter_max_recruiter_agents_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--date_expired
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET date_expired = ST.date_expired
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.date_expired <> RT.date_expired
					AND ST.date_expired IS NOT NULL;
				GET DIAGNOSTICS recruiter_date_expired_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--resume_format
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET resume_format = ST.resume_format
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.resume_format <> RT.resume_format
					AND ST.resume_format IS NOT NULL;
				GET DIAGNOSTICS recruiter_resume_format_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--first_name
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET first_name = initcap(trim(both ' ' from ST.first_name))
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND initcap(trim(both ' ' from ST.first_name)) <> RT.city
					AND initcap(trim(both ' ' from ST.first_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_first_name_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--last_name
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET last_name = initcap (trim(both ' ' from ST.last_name))
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND initcap(trim(both ' ' from ST.last_name)) <> RT.last_name
					AND initcap(trim(both ' ' from ST.last_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_last_name_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--address1
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET address1 = initcap (trim(both ' ' from ST.address1))
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND initcap(trim(both ' ' from ST.address1)) <> RT.address1
					AND initcap(trim(both ' ' from ST.address1)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_address1_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--address2
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET address2 = initcap (trim(both ' ' from ST.address2))
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND initcap(trim(both ' ' from ST.address2)) <> RT.address2
					AND initcap(trim(both ' ' from ST.address2)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_address2_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--daytime_phone
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET daytime_phone = trim(both ' ' from ST.daytime_phone)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.daytime_phone) <> RT.daytime_phone
					AND trim(both ' ' from ST.daytime_phone) IS NOT NULL;
				GET DIAGNOSTICS recruiter_daytime_phone_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--evening_phone
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET evening_phone = trim(both ' ' from ST.evening_phone)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.evening_phone) <> RT.evening_phone
					AND trim(both ' ' from ST.evening_phone) IS NOT NULL;
				GET DIAGNOSTICS recruiter_evening_phone_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--mobile_phone
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET mobile_phone = trim(both ' ' from ST.mobile_phone)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.mobile_phone) <> RT.mobile_phone
					AND trim(both ' ' from ST.mobile_phone) IS NOT NULL;
				GET DIAGNOSTICS recruiter_mobile_phone_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--fax
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET fax = trim(both ' ' from ST.fax)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.fax) <> RT.fax
					AND trim(both ' ' from ST.fax) IS NOT NULL;
				GET DIAGNOSTICS recruiter_fax_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--pager
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET pager = trim(both ' ' from ST.pager)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.pager) <> RT.pager
					AND trim(both ' ' from ST.pager) IS NOT NULL;
				GET DIAGNOSTICS recruiter_pager_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--confidential
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET confidential = ST.confidential
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.confidential <> RT.confidential
					AND ST.confidential IS NOT NULL;
				GET DIAGNOSTICS recruiter_confidential_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--company
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET company = trim(both ' ' from ST.company)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.company) <> RT.company
					AND trim(both ' ' from ST.company) IS NOT NULL;
				GET DIAGNOSTICS recruiter_company_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--career_level_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET career_level_id = ST.career_level_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.career_level_id <> RT.career_level_id
					AND ST.career_level_id IS NOT NULL
					AND ST.career_level_id <> '0';
				GET DIAGNOSTICS recruiter_career_level_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--available_time_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET available_time_id = ST.available_time_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.available_time_id <> RT.available_time_id
					AND ST.available_time_id IS NOT NULL
					AND ST.available_time_id <> '0';
				GET DIAGNOSTICS recruiter_available_time_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--available_day
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET available_day = ST.available_day
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.available_day <> RT.available_day
					AND ST.available_day IS NOT NULL
					AND ST.available_day <> '0';
				GET DIAGNOSTICS recruiter_available_day_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--available_month
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET available_month = ST.available_month
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.available_month <> RT.available_month
					AND ST.available_month IS NOT NULL
					AND ST.available_month <> '0';
				GET DIAGNOSTICS recruiter_available_month_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--available_year
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET available_year = ST.available_year
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.available_year <> RT.available_year
					AND ST.available_year IS NOT NULL
					AND ST.available_year <> '0';
				GET DIAGNOSTICS recruiter_available_year_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--location_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET location_id = ST.location_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.location_id <> RT.location_id
					AND ST.location_id IS NOT NULL
					AND ST.location_id <> '0';
				GET DIAGNOSTICS recruiter_location_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--date_modified
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET date_modified = ST.date_modified
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.date_modified <> RT.date_modified
					AND ST.date_modified IS NOT NULL;
				GET DIAGNOSTICS recruiter_date_modified_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--ats_permissions
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET ats_permissions = ST.ats_permissions
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.ats_permissions <> RT.ats_permissions
					AND ST.ats_permissions IS NOT NULL;
				GET DIAGNOSTICS recruiter_ats_permissions_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--middle_name
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET middle_name = initcap (trim(both ' ' from ST.middle_name))
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND initcap(trim(both ' ' from ST.middle_name)) <> RT.middle_name
					AND initcap(trim(both ' ' from ST.middle_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_middle_name_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--name_prefix_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET name_prefix_id = ST.name_prefix_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.name_prefix_id <> RT.name_prefix_id
					AND ST.name_prefix_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_name_prefix_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--name_suffix
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET name_suffix = initcap (trim(both ' ' from ST.name_suffix))
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND initcap(trim(both ' ' from ST.name_suffix)) <> RT.name_suffix
					AND initcap(trim(both ' ' from ST.name_suffix)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_name_suffix_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--user_date_modified
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET user_date_modified = ST.user_date_modified
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.user_date_modified <> RT.user_date_modified
					AND ST.user_date_modified IS NOT NULL;
				GET DIAGNOSTICS recruiter_user_date_modified_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--resume_notes
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET resume_notes = ST.resume_notes
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.resume_notes <> RT.resume_notes
					AND ST.resume_notes IS NOT NULL;
				GET DIAGNOSTICS recruiter_resume_notes_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--resume_routing
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET resume_routing = ST.resume_routing
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.resume_routing <> RT.resume_routing
					AND ST.resume_routing IS NOT NULL;
				GET DIAGNOSTICS recruiter_resume_routing_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--application_resume_format
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET application_resume_format = ST.application_resume_format
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
				RT.user_id = ST.user_id
					AND ST.application_resume_format <> RT.application_resume_format
					AND ST.application_resume_format IS NOT NULL;
				GET DIAGNOSTICS recruiter_application_resume_format_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--created_channel_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET created_channel_id = ST.created_channel_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.created_channel_id <> RT.created_channel_id
					AND ST.created_channel_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_created_channel_id_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--recruiter_job_title
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET recruiter_job_title = trim(both ' ' from ST.recruiter_job_title)
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND trim(both ' ' from ST.recruiter_job_title) <> RT.recruiter_job_title
					AND trim(both ' ' from ST.recruiter_job_title) IS NOT NULL;
				GET DIAGNOSTICS recruiter_recruiter_job_title_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--etl_date
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET etl_date = ST.etl_date
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.etl_date <> RT.etl_date
					AND ST.etl_date IS NOT NULL;
				GET DIAGNOSTICS recruiter_etl_date_updates = ROW_COUNT;
			--"MediaBay"."R_(01)_RecruiterDetails"--datasource_id
				UPDATE "MediaBay"."R_(01)_RecruiterDetails" RT
					SET datasource_id = ST.datasource_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails" ST
				WHERE
					RT.user_id = ST.user_id
					AND ST.datasource_id <> RT.datasource_id
					AND ST.datasource_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_datasource_id_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​eorder_tax_amount
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET eorder_tax_amount = ST.eorder_tax_amount
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.eorder_tax_amount <> RT.eorder_tax_amount AND ST.eorder_tax_amount IS NOT NULL;
				GET DIAGNOSTICS recruiter_​eorder_tax_amount_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​eorder_total_amount
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET eorder_total_amount = ST.eorder_total_amount
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.eorder_total_amount <> RT.eorder_total_amount AND ST.eorder_total_amount IS NOT NULL;
				GET DIAGNOSTICS recruiter_​​eorder_total_amount_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​po_number
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET po_number = ST.po_number
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.po_number <> RT.po_number AND ST.po_number IS NOT NULL;
				GET DIAGNOSTICS recruiter_​po_number_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​paid
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET paid = ST.paid
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.paid <> RT.paid AND ST.paid IS NOT NULL;
				GET DIAGNOSTICS recruiter_​​paid_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​create_amount
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET create_amount = ST.create_amount
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.create_amount <> RT.create_amount AND ST.create_amount IS NOT NULL;
				GET DIAGNOSTICS recruiter_​create_amount_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​member_shipin_cart
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET member_shipin_cart = ST.member_shipin_cart
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.member_shipin_cart <> RT.member_shipin_cart AND ST.member_shipin_cart IS NOT NULL;
				GET DIAGNOSTICS recruiter_​member_shipin_cart_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​total_jobs_in_cart
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET total_jobs_in_cart = ST.total_jobs_in_cart
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.total_jobs_in_cart <> RT.total_jobs_in_cart AND ST.total_jobs_in_cart IS NOT NULL;
				GET DIAGNOSTICS recruiter_​​total_jobs_in_cart_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​total_resumes_in_cart
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET total_resumes_in_cart = ST.total_resumes_in_cart
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.total_resumes_in_cart <> RT.total_resumes_in_cart AND ST.total_resumes_in_cart IS NOT NULL;
				GET DIAGNOSTICS recruiter_​total_resumes_in_cart_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​channel_id
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET channel_id = ST.channel_id
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.channel_id <> RT.channel_id AND ST.channel_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_​​channel_id_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​abandoned_cart
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET abandoned_cart = ST.abandoned_cart
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.abandoned_cart <> RT.abandoned_cart AND ST.abandoned_cart IS NOT NULL;
				GET DIAGNOSTICS recruiter_​​​abandoned_cart_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​date_modified
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET date_modified = ST.date_modified
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.date_modified <> RT.date_modified AND ST.date_modified IS NOT NULL;
				GET DIAGNOSTICS recruiter_​​​date_modified_updates = ROW_COUNT;
			--​"MediaBay"."R_(02)_RecruiterShoppingCartDetails"--​bill_back_info
				UPDATE "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT
					SET bill_back_info = ST.bill_back_info
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails" ST
				WHERE
					RT.cart_id = ST.cart_id AND ST.bill_back_info <> RT.bill_back_info AND ST.bill_back_info IS NOT NULL;
				GET DIAGNOSTICS recruiter_​​​​bill_back_info_updates = ROW_COUNT;
------------------"MediaBay"."R_(02.1)_RecruiterShoppingCartUser" --channel_id  
				UPDATE "MediaBay"."R_(02.1)_RecruiterShoppingCartUser" RT
					SET channel_id = ST.channel_id
				FROM "MediaBay"."R_STG_(02.1)_RecruiterShoppingCartUser" ST
				WHERE
					RT.user_id = ST.user_id AND RT.channel_id = ST.channel_id AND ST.application_id = RT.application_id AND ST.cart_id = RT.cart_id AND ST.datasource_id = RT.datasource_id
					AND ST.channel_id <> RT.channel_id AND ST.channel_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_​​​​user_channel_id_updates = ROW_COUNT;
			  --"MediaBay"."R_(02.1)_RecruiterShoppingCartUser"--application_id
			  	UPDATE "MediaBay"."R_(02.1)_RecruiterShoppingCartUser" RT
					SET application_id = ST.application_id
				FROM "MediaBay"."R_STG_(02.1)_RecruiterShoppingCartUser" ST
				WHERE
					RT.user_id = ST.user_id AND RT.channel_id = ST.channel_id AND ST.application_id = RT.application_id AND ST.cart_id = RT.cart_id AND ST.datasource_id = RT.datasource_id
					AND ST.application_id <> RT.application_id AND ST.application_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_user_application_id_updates = ROW_COUNT;
			  --"MediaBay"."R_(02.1)_RecruiterShoppingCartUser"--cart_id
			  	UPDATE "MediaBay"."R_(02.1)_RecruiterShoppingCartUser" RT
					SET cart_id = ST.cart_id
				FROM "MediaBay"."R_STG_(02.1)_RecruiterShoppingCartUser" ST
				WHERE
					RT.user_id = ST.user_id AND RT.channel_id = ST.channel_id AND ST.application_id = RT.application_id AND ST.cart_id = RT.cart_id AND ST.datasource_id = RT.datasource_id
					AND ST.cart_id <> RT.cart_id AND ST.cart_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_user_cart_id_updates = ROW_COUNT;
			  --"MediaBay"."R_(02.1)_RecruiterShoppingCartUser"--datasource_id
			  	UPDATE "MediaBay"."R_(02.1)_RecruiterShoppingCartUser" RT
					SET datasource_id = ST.datasource_id
				FROM "MediaBay"."R_STG_(02.1)_RecruiterShoppingCartUser" ST
				WHERE
					RT.user_id = ST.user_id AND RT.channel_id = ST.channel_id AND ST.application_id = RT.application_id AND ST.cart_id = RT.cart_id AND ST.datasource_id = RT.datasource_id
					AND ST.datasource_id <> RT.datasource_id AND ST.datasource_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_user_datasource_id_updates = ROW_COUNT;
-----------------"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--name_prefix_id
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET name_prefix_id = ST.name_prefix_id
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.name_prefix_id <> RT.name_prefix_id AND ST.name_prefix_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_name_prefix_id_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--job_title
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET job_title = trim(both ' ' from ST.job_title)
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.job_title) <> RT.job_title AND trim(both ' ' from ST.job_title) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​job_title_id_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--first_name
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET first_name = initcap(trim(both ' ' from ST.first_name))
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.first_name)) <> RT.first_name AND initcap(trim(both ' ' from ST.first_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​first_name_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--middle_name
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET middle_name = initcap(trim(both ' ' from ST.middle_name))
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.middle_name)) <> RT.middle_name AND initcap(trim(both ' ' from ST.middle_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​middle_name_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--last_name
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET last_name = initcap(trim(both ' ' from ST.last_name))
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.last_name)) <> RT.last_name AND initcap(trim(both ' ' from ST.last_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_last_name_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--company_name
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET company_name = trim(both ' ' from ST.company_name)
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.company_name) <> RT.company_name AND trim(both ' ' from ST.company_name) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​company_name_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--address1
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET address1 = initcap(trim(both ' ' from ST.address1))
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.address1)) <> RT.address1 AND initcap(trim(both ' ' from ST.address1)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​address1_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--address2
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET address2 = initcap(trim(both ' ' from ST.address2))
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.address2)) <> RT.address2 AND initcap(trim(both ' ' from ST.address2)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​address2_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--email_address
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET email_address = trim(both ' ' from ST.email_address)
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.email_address) <> RT.email_address AND trim(both ' ' from ST.email_address) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​email_address_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--cart_id
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET city = initcap(trim(both ' ' from ST.city))
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.city)) <> RT.city AND initcap(trim(both ' ' from ST.city)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​city_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--state_id
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET state_id = ST.state_id
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.state_id <> RT.state_id AND ST.state_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​​state_id_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--zip_code
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET zip_code = trim(both ' ' from ST.zip_code)
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.zip_code) <> RT.zip_code AND trim(both ' ' from ST.zip_code) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​​​zip_code_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--phone_number
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET phone_number = trim(both ' ' from ST.phone_number)
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.phone_number) <> RT.phone_number AND trim(both ' ' from ST.phone_number) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​​​​phone_number_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--fax_number
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET fax_number = trim(both ' ' from ST.fax_number)
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.fax_number) <> RT.fax_number AND trim(both ' ' from ST.fax_number) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​​​​​fax_number_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--how_header_id
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET how_header_id = ST.how_header_id
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.how_header_id <> RT.how_header_id AND ST.how_header_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​how_header_id_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--allow_marketing
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET allow_marketing = ST.allow_marketing
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.allow_marketing <> RT.allow_marketing AND ST.allow_marketing IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​allow_marketing_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--date_modified
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET date_modified = ST.date_modified
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.date_modified <> RT.date_modified AND ST.date_modified IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​​date_modified_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--job_function_id
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET job_function_id = ST.job_function_id
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.job_function_id <> RT.job_function_id AND ST.job_function_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​job_function_id_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--karma_company_size_id
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET karma_company_size_id = ST.karma_company_size_id
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.karma_company_size_id <> RT.karma_company_size_id AND ST.karma_company_size_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​karma_company_size_id_updates = ROW_COUNT;
			--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"--company_id
				UPDATE "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" RT
					SET company_id = ST.company_id
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.company_id <> RT.company_id AND ST.company_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​​company_id_updates = ROW_COUNT;
----------------"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--name_prefix_id
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET name_prefix_id = ST.name_prefix_id
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.name_prefix_id <> RT.name_prefix_id AND ST.name_prefix_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_name_prefix_id_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--first_name
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET first_name = initcap(trim(both ' ' from ST.first_name))
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.first_name)) <> RT.first_name AND initcap(trim(both ' ' from ST.first_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_first_name_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--middle_name
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET middle_name = initcap(trim(both ' ' from ST.middle_name))
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.middle_name)) <> RT.middle_name AND initcap(trim(both ' ' from ST.middle_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_middle_name_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--last_name
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET last_name = initcap(trim(both ' ' from ST.last_name))
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.last_name)) <> RT.last_name AND initcap(trim(both ' ' from ST.last_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billling_last_name_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--company
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET last_name = trim(both ' ' from ST.company)
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.company) <> RT.company AND trim(both ' ' from ST.company) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_company_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--address1
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET address1 = initcap(trim(both ' ' from ST.address1))
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.address1)) <> RT.address1 AND initcap(trim(both ' ' from ST.address1)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_address1_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--address2
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET address2 = initcap(trim(both ' ' from ST.address2))
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.address2)) <> RT.address2 AND initcap(trim(both ' ' from ST.address2)) IS NOT NULL;
				GET DIAGNOSTICS creduiter_billing_address2_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--email_address
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET email_address = trim(both ' ' from ST.email_address)
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.email_address) <> RT.email_address AND trim(both ' ' from ST.email_address) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_email_address_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--city
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET city = initcap(trim(both ' ' from ST.city))
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND initcap(trim(both ' ' from ST.city)) <> RT.city AND initcap(trim(both ' ' from ST.city)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_city_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--state_id
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET state_id = ST.state_id
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.state_id <> RT.state_id AND ST.state_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_state_id_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--zip_code
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET zip_code = trim(both ' ' from ST.zip_code)
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.zip_code) <> RT.zip_code AND trim(both ' ' from ST.zip_code) IS NOT NULL;
				GET DIAGNOSTICS recruiter_contact_​​​​zip_code_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--phone_number
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET phone_number = trim(both ' ' from ST.phone_number)
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.phone_number) <> RT.phone_number AND trim(both ' ' from ST.phone_number) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_phone_number_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--fax_number
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET fax_number = trim(both ' ' from ST.fax_number)
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.fax_number) <> RT.fax_number AND trim(both ' ' from ST.fax_number) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_fax_number_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--po_number
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET po_number = trim(both ' ' from ST.po_number)
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND trim(both ' ' from ST.po_number) <> RT.po_number AND trim(both ' ' from ST.po_number) IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_po_number_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--payment_type_id
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET payment_type_id = ST.payment_type_id
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.payment_type_id <> RT.payment_type_id AND ST.payment_type_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_payment_type_id_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--paypal_token
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET paypal_token = ST.paypal_token
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.paypal_token <> RT.paypal_token AND ST.paypal_token IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_paypal_token_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--paypal_payer_id
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET paypal_payer_id = ST.paypal_payer_id
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.paypal_payer_id <> RT.paypal_payer_id AND ST.paypal_payer_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_paypal_payer_id_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--bank_account_type_id
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET bank_account_type_id = ST.bank_account_type_id
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.bank_account_type_id <> RT.bank_account_type_id AND ST.bank_account_type_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_bank_account_type_id_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--bank_routing_number
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET bank_routing_number = ST.bank_routing_number
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.bank_routing_number <> RT.bank_routing_number AND ST.bank_routing_number IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_bank_routing_number_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--bank_account_number
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET bank_account_number = ST.bank_account_number
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.bank_account_number <> RT.bank_account_number AND ST.bank_account_number IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_bank_account_number_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--split_billing
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET split_billing = ST.split_billing
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.split_billing <> RT.split_billing AND ST.split_billing IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_split_billing_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--country_id
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET country_id = ST.country_id
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.country_id <> RT.country_id AND ST.country_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_country_id_updates = ROW_COUNT;
			---"MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"--datasource_id
				UPDATE "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" RT
					SET datasource_id = ST.datasource_id
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST
				WHERE
					ST.cart_id = RT.cart_id AND ST.datasource_id <> RT.datasource_id AND ST.datasource_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_billing_datasource_id_updates = ROW_COUNT;
-----------------"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --user_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET user_id = ST.user_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.user_id <> RT.user_id AND ST.user_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_user_id_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --cart_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET cart_id = ST.cart_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.cart_id <> RT.cart_id AND ST.cart_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_cart_id_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --channel_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET channel_id = ST.channel_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.channel_id <> RT.channel_id AND ST.channel_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_channel_id_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --application_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET application_id = ST.application_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.application_id <> RT.application_id AND ST.application_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_application_id_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --first_name
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET first_name = initcap(trim(both ' ' from ST.first_name))
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND initcap(trim(both ' ' from ST.first_name)) <> RT.first_name AND initcap(trim(both ' ' from ST.first_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_first_name_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --middle_name
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET middle_name = initcap(trim(both ' ' from ST.middle_name))
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND initcap(trim(both ' ' from ST.middle_name)) <> RT.middle_name AND initcap(trim(both ' ' from ST.middle_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_middle_name_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --last_name
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET last_name = initcap(trim(both ' ' from ST.last_name))
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND initcap(trim(both ' ' from ST.last_name)) <> RT.last_name AND initcap(trim(both ' ' from ST.last_name)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_last_name_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --company_name
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET company_name = trim(both ' ' from ST.company_name)
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND trim(both ' ' from ST.company_name) <> RT.company_name AND trim(both ' ' from ST.company_name) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_company_name_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --address1
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET address1 = initcap(trim(both ' ' from ST.address1))
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND initcap(trim(both ' ' from ST.address1)) <> RT.address1 AND initcap(trim(both ' ' from ST.address1)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_address1_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --address2
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET address2 = initcap(trim(both ' ' from ST.address2))
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND initcap(trim(both ' ' from ST.address2)) <> RT.address2 AND initcap(trim(both ' ' from ST.address2)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_address2_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --email_address
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET email_address = trim(both ' ' from ST.email_address)
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND trim(both ' ' from ST.email_address) <> RT.email_address AND trim(both ' ' from ST.email_address) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_email_address_updates = ROW_COUNT;				
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --company_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET company_id = ST.company_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.company_id <> RT.company_id AND ST.company_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_company_id_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --date_expired
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET date_expired = ST.date_expired
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.date_expired <> RT.date_expired AND ST.date_expired IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_date_expired_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --disabled
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET disabled = ST.disabled
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.disabled <> RT.disabled AND ST.disabled IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_disabled_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --state_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET state_id = ST.state_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.state_id <> RT.state_id AND ST.state_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_state_id_updatest = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --country_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET country_id = ST.country_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.country_id <> RT.country_id AND ST.country_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_country_id_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --confidential
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET confidential = ST.confidential
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.confidential <> RT.confidential AND ST.confidential IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_confidential_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --company
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET company = initcap(trim(both ' ' from ST.company))
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND initcap(trim(both ' ' from ST.company)) <> RT.company AND initcap(trim(both ' ' from ST.company)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_company_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --date_last_login
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET date_last_login = ST.date_last_login
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.date_last_login <> RT.date_last_login AND ST.date_last_login IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_date_last_login_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --location_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET location_id = ST.location_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.location_id <> RT.location_id AND ST.location_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_location_id_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --name_prefix_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET name_prefix_id = ST.name_prefix_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.name_prefix_id <> RT.name_prefix_id AND ST.name_prefix_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_name_prefix_id_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --name_suffix
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET name_suffix = initcap(trim(both ' ' from ST.name_suffix))
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND initcap(trim(both ' ' from ST.name_suffix)) <> RT.name_suffix AND initcap(trim(both ' ' from ST.name_suffix)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_name_suffix_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --city
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET city = initcap(trim(both ' ' from ST.city))
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND initcap(trim(both ' ' from ST.city)) <> RT.city AND initcap(trim(both ' ' from ST.city)) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_city_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --postal_code
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET postal_code = trim(both ' ' from ST.postal_code)
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND trim(both ' ' from ST.postal_code) <> RT.postal_code AND trim(both ' ' from ST.postal_code) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_postal_code_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --daytime_phone
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET daytime_phone = trim(both ' ' from ST.daytime_phone)
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND trim(both ' ' from ST.daytime_phone) <> RT.daytime_phone AND trim(both ' ' from ST.daytime_phone) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_daytime_phone_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --evening_phone
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET evening_phone = trim(both ' ' from ST.evening_phone)
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND trim(both ' ' from ST.evening_phone) <> RT.evening_phone AND trim(both ' ' from ST.evening_phone) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_evening_phone_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --mobile_phone
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET mobile_phone = trim(both ' ' from ST.mobile_phone)
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND trim(both ' ' from ST.mobile_phone) <> RT.mobile_phone AND trim(both ' ' from ST.mobile_phone) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_mobile_phone_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --fax
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET fax = trim(both ' ' from ST.fax)
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND trim(both ' ' from ST.fax) <> RT.fax AND trim(both ' ' from ST.fax) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_fax_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --pager
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET pager = trim(both ' ' from ST.pager)
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND trim(both ' ' from ST.pager) <> RT.pager AND trim(both ' ' from ST.pager) IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_pager_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --date_modified
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET date_modified = ST.date_modified
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.date_modified <> RT.date_modified AND ST.date_modified IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_date_modified_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --etl_date
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET etl_date = ST.etl_date
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.etl_date <> RT.etl_date AND ST.etl_date IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_etl_date_updates = ROW_COUNT;
			--"MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" --datasource_id
				UPDATE "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" RT
					SET datasource_id = ST.datasource_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST
				WHERE
					ST.line_item_id = RT.line_item_id AND ST.datasource_id <> RT.datasource_id AND ST.datasource_id IS NOT NULL;
				GET DIAGNOSTICS recruiter_abb_cart_datasource_id_updates = ROW_COUNT;
													
				RETURN QUERY SELECT
						recruiter_disabled_updates, recruiter_email_address_updates, recruiter_city_updates, recruiter_state_id_updates, recruiter_postal_code_updates, recruiter_country_id_updates, recruiter_channel_id_updates, recruiter_company_id_updates, recruiter_email_address_resumes_updates, recruiter_auto_user_updates, recruiter_edit_jobs_updates, 
						recruiter_edit_user_profile_updates, recruiter_manage_company_job_updates, recruiter_manage_company_letter_updates, recruiter_manage_company_users_updates, recruiter_manage_corp_jobs_updates, recruiter_manage_corp_users_updates, recruiter_manage_jobs_updates, recruiter_manage_letters_updates, recruiter_pre_screen_updates, 
						recruiter_post_jobs_updates, recruiter_search_resumes_updates, recruiter_max_recruiter_agents_updates, recruiter_date_expired_updates, recruiter_resume_format_updates, recruiter_first_name_updates, recruiter_last_name_updates, recruiter_address1_updates, recruiter_address2_updates, recruiter_daytime_phone_updates, 
						recruiter_evening_phone_updates, recruiter_mobile_phone_updates, recruiter_fax_updates, recruiter_pager_updates, recruiter_confidential_updates, recruiter_company_updates, recruiter_career_level_id_updates, recruiter_available_time_id_updates, recruiter_available_day_updates, recruiter_available_month_updates, recruiter_available_year_updates, 
						recruiter_location_id_updates, recruiter_date_modified_updates, recruiter_ats_permissions_updates, recruiter_middle_name_updates, recruiter_name_prefix_id_updates, recruiter_name_suffix_updates, recruiter_user_date_modified_updates, recruiter_resume_notes_updates, recruiter_resume_routing_updates, recruiter_application_resume_format_updates, 
						recruiter_created_channel_id_updates, recruiter_recruiter_job_title_updates, recruiter_etl_date_updates, recruiter_datasource_id_updates, 
						--
						recruiter_​eorder_tax_amount_updates, recruiter_​​eorder_total_amount_updates, recruiter_​po_number_updates, recruiter_​​paid_updates, recruiter_​create_amount_updates, recruiter_​member_shipin_cart_updates, recruiter_​​total_jobs_in_cart_updates, recruiter_​total_resumes_in_cart_updates, recruiter_​​channel_id_updates,
						recruiter_​​​abandoned_cart_updates, recruiter_​​​date_modified_updates, recruiter_​​​​bill_back_info_updates,
						recruiter_billing_name_prefix_id_updates, recruiter_billing_first_name_updates, recruiter_billing_middle_name_updates, recruiter_billling_last_name_updates, recruiter_billing_company_updates, recruiter_billing_address1_updates, creduiter_billing_address2_updates, recruiter_billing_email_address_updates, recruiter_billing_city_updates, recruiter_billing_state_id_updates, recruiter_billing_zip_code_updates, recruiter_billing_phone_number_updates, recruiter_billing_fax_number_updates, recruiter_billing_po_number_updates, recruiter_billing_payment_type_id_updates, recruiter_billing_paypal_token_updates, recruiter_billing_paypal_payer_id_updates, recruiter_billing_bank_account_type_id_updates, recruiter_billing_bank_routing_number_updates, recruiter_billing_bank_account_number_updates, recruiter_billing_split_billing_updates, recruiter_billing_country_id_updates, recruiter_billing_datasource_id_updates,
						recruiter_abb_cart_user_id_updates, recruiter_abb_cart_cart_id_updates, recruiter_abb_cart_channel_id_updates, recruiter_abb_cart_application_id_updates, recruiter_abb_cart_first_name_updates, recruiter_abb_cart_middle_name_updates, recruiter_abb_cart_last_name_updates, recruiter_abb_cart_company_name_updates, recruiter_abb_cart_address1_updates, recruiter_abb_cart_address2_updates, recruiter_abb_cart_email_address_updates, recruiter_abb_cart_company_id_updates, recruiter_abb_cart_date_expired_updates, recruiter_abb_cart_disabled_updates, recruiter_abb_cart_state_id_updatest, recruiter_abb_cart_country_id_updates, recruiter_abb_cart_confidential_updates, recruiter_abb_cart_company_updates, recruiter_abb_cart_date_last_login_updates, recruiter_abb_cart_location_id_updates, recruiter_abb_cart_name_prefix_id_updates, recruiter_abb_cart_name_suffix_updates, recruiter_abb_cart_city_updates, recruiter_abb_cart_postal_code_updates, recruiter_abb_cart_daytime_phone_updates, recruiter_abb_cart_evening_phone_updates, recruiter_abb_cart_mobile_phone_updates, recruiter_abb_cart_fax_updates, recruiter_abb_cart_pager_updates, recruiter_abb_cart_date_modified_updates, recruiter_abb_cart_etl_date_updates, recruiter_abb_cart_datasource_id_updates;
		END;

$$;

