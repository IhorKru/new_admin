CREATE TRIGGER block_proc_d
BEFORE DELETE ON proc
FOR EACH ROW
  BEGIN
DECLARE foo varchar(255);
if old.Definer = "rdsadmin@localhost" then
  select `ERROR (RDS): CANNOT DROP RDSDMIN OBJECT` into foo;
end if;
END;
