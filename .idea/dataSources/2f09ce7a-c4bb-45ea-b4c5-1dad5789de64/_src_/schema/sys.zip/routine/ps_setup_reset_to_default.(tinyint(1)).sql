CREATE PROCEDURE ps_setup_reset_to_default(IN in_verbose TINYINT(1))
  BEGIN
    SET @query = 'DELETE
                    FROM performance_schema.setup_actors
                   WHERE NOT (HOST = '%' AND USER = '%' AND ROLE = '%')';

    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_actors
', REPLACE(@query, '  ', '')) AS status;
    END IF;

    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;

    SET @query = 'INSERT IGNORE INTO performance_schema.setup_actors
                  VALUES ('%', '%', '%')';

    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_actors
', REPLACE(@query, '  ', '')) AS status;
    END IF;

    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;

    SET @query = 'UPDATE performance_schema.setup_instruments
                     SET ENABLED = sys.ps_is_instrument_default_enabled(NAME),
                         TIMED   = sys.ps_is_instrument_default_timed(NAME)';

    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_instruments
', REPLACE(@query, '  ', '')) AS status;
    END IF;

    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
         
    SET @query = 'UPDATE performance_schema.setup_consumers
                     SET ENABLED = IF(NAME IN ('events_statements_current', 'global_instrumentation', 'thread_instrumentation', 'statements_digest'), 'YES', 'NO')';

    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_consumers
', REPLACE(@query, '  ', '')) AS status;
    END IF;

    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;

    SET @query = 'DELETE
                    FROM performance_schema.setup_objects
                   WHERE NOT (OBJECT_TYPE = 'TABLE' AND OBJECT_NAME = '%'
                     AND (OBJECT_SCHEMA = 'mysql'              AND ENABLED = 'NO'  AND TIMED = 'NO' )
                      OR (OBJECT_SCHEMA = 'performance_schema' AND ENABLED = 'NO'  AND TIMED = 'NO' )
                      OR (OBJECT_SCHEMA = 'information_schema' AND ENABLED = 'NO'  AND TIMED = 'NO' )
                      OR (OBJECT_SCHEMA = '%'                  AND ENABLED = 'YES' AND TIMED = 'YES'))';

    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_objects
', REPLACE(@query, '  ', '')) AS status;
    END IF;

    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;

    SET @query = 'INSERT IGNORE INTO performance_schema.setup_objects
                  VALUES ('TABLE', 'mysql'             , '%', 'NO' , 'NO' ),
                         ('TABLE', 'performance_schema', '%', 'NO' , 'NO' ),
                         ('TABLE', 'information_schema', '%', 'NO' , 'NO' ),
                         ('TABLE', '%'                 , '%', 'YES', 'YES')';

    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_objects
', REPLACE(@query, '  ', '')) AS status;
    END IF;

    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;

    SET @query = 'UPDATE performance_schema.threads
                     SET INSTRUMENTED = 'YES'';

    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: threads
', REPLACE(@query, '  ', '')) AS status;
    END IF;

    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
END;
